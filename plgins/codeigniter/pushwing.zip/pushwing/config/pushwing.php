<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
$config['pushwing_server'] = 'www.pushwing.com'; // PushWing server 주소
$config['pushwing_id'] = 'test'; // PushWing ID
$config['pushwing_password'] = '1234'; // PushWing 비밀번호
$config['client_id'] = '1'; // PushWing Client ID
